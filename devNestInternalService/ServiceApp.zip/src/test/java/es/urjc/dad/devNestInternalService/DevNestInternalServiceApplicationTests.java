package es.urjc.dad.devNestInternalService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevNestInternalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
